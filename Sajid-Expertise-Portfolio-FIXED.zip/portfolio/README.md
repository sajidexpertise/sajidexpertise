# Sajid Expertise — Interactive Data Analyst Portfolio

A production-ready, responsive portfolio for **Sajid Ali / Sajid Expertise**. It includes a transparent professional portrait, a directly readable résumé, 15 interactive analytics project labs, real YouTube links, SEO metadata, motion, hover effects, mobile navigation, and accessible project dialogs.

## Start it locally

Requirements: Node.js 22.13 or newer.

```bash
npm install
npm run dev
```

Open the exact URL shown in the terminal (normally `http://localhost:3000`). Keep the terminal open while viewing the site. Stop it with `Ctrl + C`.

For a production check:

```bash
npm run lint
npm run build
```

## Quick customization map

You can safely edit these files in VS Code:

| What to change | File | Search for |
| --- | --- | --- |
| Name, intro, contact links, YouTube links, section text | `app/page.tsx` | `Sajid Ali`, `channelUrl`, `linkedinUrl`, `email` |
| All 15 project titles, metrics, tools and insights | `app/projects.ts` | `export const projects` |
| Colors, spacing, glass style, animation and mobile layout | `app/globals.css` | `:root` and `@media` |
| Browser/Google title, description and keywords | `app/layout.tsx` | `export const metadata` |
| Professional hero portrait | `public/sajid-profile-transparent.png` | Replace with the same filename |
| Résumé PDF | `public/sajid-ali-cv.pdf` | Replace with the same filename |
| Large résumé image | `public/sajid-ali-cv.png` | Replace with the same filename |

### Replace your portrait

1. Prepare a transparent PNG (portrait orientation works best).
2. Rename it to `sajid-profile-transparent.png`.
3. Drag it into the `public` folder and choose **Replace**.
4. Save and refresh the browser.

### Replace your CV

Replace both files in `public`:

- `sajid-ali-cv.pdf` is used by Open and Download buttons.
- `sajid-ali-cv.png` is the large readable page preview.

Export the first/full CV page as a high-quality PNG. Keep the filenames unchanged so no code edit is needed.

### Edit or add a project

Open `app/projects.ts`. Every project is one object in the `projects` array. Duplicate an object, give it a unique `id`, and change its fields. Its chart and project modal are generated automatically.

The category must be one of `Power BI`, `SQL`, `Python`, `Excel`, or `Creator` to appear under the existing filters. If you add another category, also add it to the `filters` array near the top of `app/page.tsx`.

## Important editing notes

- Do not edit `package-lock.json` or anything inside `node_modules`.
- Do not claim demo projects as paid client work. The site clearly labels them as portfolio simulations.
- Keep external links beginning with `https://` and email links beginning with `mailto:`.
- After changing a filename in `public`, update every matching `/filename.ext` reference in `app/page.tsx` or `app/layout.tsx`.
- Motion automatically reduces for visitors who enable **Reduce motion** in their device settings.

## Deployment

This repository is configured for ChatGPT Sites through `.openai/hosting.json`. A verified production checkpoint can be published directly from the Sites workflow.

The same source is also ready for Vercel through `vercel.json`:

1. Upload this folder to a new GitHub repository.
2. In Vercel, choose **Add New → Project** and import that repository.
3. Keep the detected settings; `vercel.json` selects the correct Next.js build automatically.
4. Click **Deploy**.

For a local Vercel-style preview, run `npm run dev:vercel`.

## Project structure

```text
app/
  globals.css       Visual design, motion and responsive styles
  layout.tsx        SEO metadata and global layout
  page.tsx          Homepage, interactions and project experience
  projects.ts       Editable data for all 15 project labs
  robots.ts         Search crawler rules
  sitemap.ts        Search sitemap
public/
  sajid-profile-transparent.png
  sajid-ali-cv.pdf
  sajid-ali-cv.png
```
