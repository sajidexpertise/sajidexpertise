"use client";

import Image from "next/image";
import {
  useEffect,
  useMemo,
  useState,
  type CSSProperties,
  type MouseEvent as ReactMouseEvent,
} from "react";
import { projects, type Project } from "./projects";

type ChannelVideo = {
  id: string;
  title: string;
  published: string;
  url: string;
  thumbnail: string;
};

const filters = ["All", "Power BI", "SQL", "Python", "Excel", "Creator"];
const channelId = "UC6ZckektFwLUMnZ4bSHKQhQ";
const uploadsPlaylistId = "UU6ZckektFwLUMnZ4bSHKQhQ";
const channelUrl = `https://www.youtube.com/channel/${channelId}`;
const linkedinUrl = "https://pk.linkedin.com/in/sajidexpertise";
const email = "sajidrindofficial@gmail.com";

const fallbackVideos: ChannelVideo[] = [
  {
    id: "t9_Byx-j0Ws",
    title: "5 High-Paying Skills to Learn Before 2030",
    published: "2026-01-01T00:00:00.000Z",
    url: "https://www.youtube.com/watch?v=t9_Byx-j0Ws",
    thumbnail: "https://i.ytimg.com/vi/t9_Byx-j0Ws/hqdefault.jpg",
  },
  {
    id: "1O3rmIa5HzU",
    title: "Top 5 Free AI Tools Everyone Must Use",
    published: "2026-01-01T00:00:00.000Z",
    url: "https://www.youtube.com/watch?v=1O3rmIa5HzU",
    thumbnail: "https://i.ytimg.com/vi/1O3rmIa5HzU/hqdefault.jpg",
  },
  {
    id: "pUkQSHW7W6Y",
    title: "Viral YouTube Thumbnail Ideas",
    published: "2026-01-01T00:00:00.000Z",
    url: "https://www.youtube.com/watch?v=pUkQSHW7W6Y",
    thumbnail: "https://i.ytimg.com/vi/pUkQSHW7W6Y/hqdefault.jpg",
  },
];

const capabilities = [
  {
    number: "01",
    title: "Business intelligence",
    copy: "Executive dashboards, data models, DAX measures and decision-ready KPI systems.",
    signal: "POWER BI · DAX",
  },
  {
    number: "02",
    title: "Analytical problem solving",
    copy: "SQL exploration, Python analysis, segmentation and explainable forecasting.",
    signal: "SQL · PYTHON",
  },
  {
    number: "03",
    title: "Creator intelligence",
    copy: "Channel performance, audience signals, packaging experiments and publishing strategy.",
    signal: "YOUTUBE · CONTENT",
  },
  {
    number: "04",
    title: "Clear communication",
    copy: "Simple stories connecting the metric, its driver and the next useful business action.",
    signal: "STORY · IMPACT",
  },
];

const toolGroups = [
  { title: "Visualize", items: ["Power BI", "Looker Studio", "Excel", "Tableau", "DAX"] },
  { title: "Analyze", items: ["SQL", "Python", "Pandas", "Statistics", "Machine Learning"] },
  { title: "Prepare", items: ["Power Query", "ETL", "Data Modeling", "Data QA", "BigQuery"] },
  { title: "Communicate", items: ["KPI Design", "Storytelling", "YouTube", "Figma", "Presentations"] },
];

const schema = {
  "@context": "https://schema.org",
  "@type": "Person",
  name: "Sajid Ali",
  alternateName: "Sajid Expertise",
  jobTitle: "Data Analyst and YouTube Creator",
  description:
    "Data analyst portfolio featuring interactive Power BI, SQL, Python, Excel and creator analytics projects.",
  url: "https://sajid-expertise-pro.sajidrindofficial.chatgpt.site",
  image: "https://sajid-expertise-pro.sajidrindofficial.chatgpt.site/sajid-hero-v2.png",
  sameAs: [linkedinUrl, channelUrl],
  email: `mailto:${email}`,
  knowsAbout: ["Data Analysis", "Power BI", "SQL", "Python", "Excel", "YouTube Analytics"],
};

function updatePointerGlow(element: HTMLElement, clientX: number, clientY: number) {
  const bounds = element.getBoundingClientRect();
  const x = clientX - bounds.left;
  const y = clientY - bounds.top;
  const rotateX = ((y / bounds.height - 0.5) * -7).toFixed(2);
  const rotateY = ((x / bounds.width - 0.5) * 7).toFixed(2);
  element.style.setProperty("--mx", `${x}px`);
  element.style.setProperty("--my", `${y}px`);
  element.style.setProperty("--rx", `${rotateX}deg`);
  element.style.setProperty("--ry", `${rotateY}deg`);
}

function resetTilt(element: HTMLElement) {
  element.style.setProperty("--rx", "0deg");
  element.style.setProperty("--ry", "0deg");
}

function isShort(video: { title: string }) {
  return /#\s?shorts?\b/i.test(video.title);
}

function fixedDate(value: string) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "LATEST UPLOAD";
  const months = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"];
  return `${months[date.getUTCMonth()]} ${date.getUTCDate()}, ${date.getUTCFullYear()}`;
}

export default function Home() {
  const [filter, setFilter] = useState("All");
  const [activeProject, setActiveProject] = useState<Project | null>(null);
  const [activeVideo, setActiveVideo] = useState<ChannelVideo | null>(null);
  const [videos, setVideos] = useState<ChannelVideo[]>(fallbackVideos.filter((video) => !isShort(video)));
  const [feedSource, setFeedSource] = useState<"loading" | "live" | "fallback">("loading");
  const [menuOpen, setMenuOpen] = useState(false);

  const visibleProjects = useMemo(
    () => (filter === "All" ? projects : projects.filter((project) => project.category === filter)),
    [filter],
  );

  useEffect(() => {
    const root = document.documentElement;
    const aura = document.querySelector<HTMLElement>(".pointerAura");
    let targetX = -100;
    let targetY = -100;
    let auraX = -100;
    let auraY = -100;
    let raf = 0;
    let started = false;

    const onPointerMove = (event: PointerEvent) => {
      targetX = event.clientX;
      targetY = event.clientY;
      const isInteractive = (event.target as HTMLElement | null)?.closest(
        "a, button, [role='button'], input, .tiltSurface",
      );
      aura?.classList.toggle("isActive", Boolean(isInteractive));
      if (!started) {
        auraX = targetX;
        auraY = targetY;
        started = true;
      }
    };
    const animate = () => {
      // ease the glow toward the real cursor position for a smooth, realtime trail
      auraX += (targetX - auraX) * 0.16;
      auraY += (targetY - auraY) * 0.16;
      root.style.setProperty("--cursor-x", `${auraX}px`);
      root.style.setProperty("--cursor-y", `${auraY}px`);
      raf = requestAnimationFrame(animate);
    };
    const onScroll = () => {
      const scrollable = document.body.scrollHeight - window.innerHeight;
      root.style.setProperty("--scroll", `${scrollable > 0 ? window.scrollY / scrollable : 0}`);
    };

    window.addEventListener("pointermove", onPointerMove, { passive: true });
    window.addEventListener("scroll", onScroll, { passive: true });
    onScroll();
    raf = requestAnimationFrame(animate);
    return () => {
      window.removeEventListener("pointermove", onPointerMove);
      window.removeEventListener("scroll", onScroll);
      cancelAnimationFrame(raf);
    };
  }, []);

  useEffect(() => {
    const items = document.querySelectorAll<HTMLElement>("[data-reveal]");
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("is-visible");
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.1, rootMargin: "0px 0px -30px" },
    );
    items.forEach((item) => observer.observe(item));
    return () => observer.disconnect();
  }, [filter, videos]);

  useEffect(() => {
    let cancelled = false;
    fetch("/api/youtube")
      .then((response) => response.json())
      .then((data: { videos?: ChannelVideo[]; source?: "live" | "fallback" }) => {
        if (cancelled) return;
        if (data.videos?.length) setVideos(data.videos.filter((video) => !isShort(video)));
        setFeedSource(data.source === "live" ? "live" : "fallback");
      })
      .catch(() => {
        if (!cancelled) setFeedSource("fallback");
      });
    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    if (!activeVideo) return;
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") setActiveVideo(null);
    };
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = previous;
      window.removeEventListener("keydown", onKey);
    };
  }, [activeVideo]);

  const closeMenu = () => setMenuOpen(false);

  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(schema) }} />
      <div className="scrollProgress" aria-hidden="true" />
      <div className="pointerAura" aria-hidden="true" />
      <div className="pageGrain" aria-hidden="true" />

      <header className="siteHeader">
        <a className="brand" href="#top" onClick={closeMenu} aria-label="Sajid Expertise home">
          <span className="brandMark">SE</span>
          <span className="brandWords"><b>Sajid Expertise</b><small>DATA ANALYST × CREATOR</small></span>
        </a>
        <nav className={menuOpen ? "navMenu open" : "navMenu"} aria-label="Primary navigation">
          <a href="#story" onClick={closeMenu}>Story</a>
          <a href="#work" onClick={closeMenu}>Projects</a>
          <a href="#channel" onClick={closeMenu}>YouTube</a>
          <a href="#resume" onClick={closeMenu}>CV</a>
          <a href="#profiles" onClick={closeMenu}>Profiles</a>
        </nav>
        <a className="headerCta magnetic" href={`mailto:${email}`}>Let&apos;s connect <span>↗</span></a>
        <button
          className="menuButton"
          type="button"
          aria-expanded={menuOpen}
          aria-label="Toggle navigation"
          onClick={() => setMenuOpen((value) => !value)}
        >
          <span /><span />
        </button>
      </header>

      <main id="top">
        <section className="hero shell">
          <div className="heroCopy" data-reveal>
            <div className="availability"><i /> AVAILABLE FOR DATA ANALYST OPPORTUNITIES</div>
            <p className="eyebrow">HELLO, I&apos;M SAJID ALI — PAKISTAN</p>
            <h1>Turning complex data into <em>confident decisions.</em></h1>
            <p className="heroLead">
              I build business-ready dashboards, analytical systems and visual stories with Power BI,
              SQL, Python and Excel—then explain them with a creator&apos;s clarity.
            </p>
            <div className="heroActions">
              <a className="button buttonPrimary magnetic" href="#work">Explore 15 projects <span>↓</span></a>
              <a className="button buttonGhost magnetic" href="/sajid-ali-cv.pdf" target="_blank" rel="noreferrer">Open my CV <span>↗</span></a>
            </div>
            <div className="heroProof" aria-label="Portfolio highlights">
              <div><strong>15</strong><span>Interactive<br />analytics labs</span></div>
              <div><strong>73</strong><span>Published<br />YouTube videos</span></div>
              <div><strong>4</strong><span>Core analytics<br />ecosystems</span></div>
            </div>
          </div>

          <div
            className="heroVisual tiltSurface"
            data-reveal
            onMouseMove={(event) => updatePointerGlow(event.currentTarget, event.clientX, event.clientY)}
            onMouseLeave={(event) => resetTilt(event.currentTarget)}
          >
            <div className="portraitBlob" aria-hidden="true" />
            <div className="portraitHalo haloOne" aria-hidden="true" />
            <div className="portraitHalo haloTwo" aria-hidden="true" />
            <div className="heroPortrait">
              <Image
                src="/sajid-hero-v2.webp"
                alt="Sajid Ali, data analyst and digital creator"
                fill
                priority
                unoptimized
                style={{ objectFit: "contain", objectPosition: "center bottom" }}
                sizes="(max-width: 900px) 94vw, 48vw"
              />
            </div>
            <div className="floatCard floatCardTop">
              <span className="floatIcon">↗</span>
              <small>BUSINESS SIGNAL</small>
              <strong>Decision-ready</strong>
              <div className="tinySpark"><i /><i /><i /><i /><i /><i /></div>
            </div>
            <div className="floatCard floatCardBottom">
              <span className="powerTile">BI</span>
              <div><small>CORE STACK</small><strong>Power BI · SQL</strong></div>
            </div>
            <div className="orbitLabel orbitOne">PYTHON</div>
            <div className="orbitLabel orbitTwo">EXCEL</div>
            <div className="heroCaption"><i /> DATA × STORY × IMPACT</div>
          </div>
        </section>

        <div className="ticker" aria-hidden="true">
          <div>
            <span>POWER BI <b>✦</b> SQL <b>✦</b> PYTHON <b>✦</b> EXCEL <b>✦</b> DATA STORYTELLING <b>✦</b> YOUTUBE ANALYTICS <b>✦</b> KPI DESIGN <b>✦</b></span>
            <span>POWER BI <b>✦</b> SQL <b>✦</b> PYTHON <b>✦</b> EXCEL <b>✦</b> DATA STORYTELLING <b>✦</b> YOUTUBE ANALYTICS <b>✦</b> KPI DESIGN <b>✦</b></span>
          </div>
        </div>

        <section className="story" id="story">
          <div className="shell storyGrid">
            <div className="storyPortraitPanel tiltSurface" data-reveal>
              <div className="storyShape" aria-hidden="true" />
              <div className="storyDots" aria-hidden="true"><i /><i /><i /><i /><i /><i /></div>
              <Image
                src="/sajid-about-v2.webp"
                alt="Sajid Ali in a professional arms-crossed pose"
                fill
                unoptimized
                style={{ objectFit: "contain", objectPosition: "center bottom" }}
                sizes="(max-width: 900px) 94vw, 43vw"
              />
              <div className="portraitNote"><span>01</span><p><b>ANALYST + EDUCATOR</b>Turning technical work into something people can understand and use.</p></div>
            </div>

            <div className="storyCopy" data-reveal>
              <p className="sectionLabel"><span>01</span> ABOUT SAJID</p>
              <h2>Curious with the data.<br /><em>Clear with the answer.</em></h2>
              <p className="storyLead">
                I&apos;m an IT graduate focused on data analytics and building toward data science. My work combines
                technical analysis with the visual communication I developed through YouTube, Shopify and digital content.
              </p>
              <div className="missionGrid">
                <article><span>VISION</span><h3>Make data feel useful.</h3><p>Turn scattered information into a story that helps a team move with confidence.</p></article>
                <article><span>MISSION</span><h3>Build for action.</h3><p>Create clear dashboards and analysis that answer the real business question.</p></article>
              </div>
              <div className="storyStats">
                <div><strong>15</strong><span>Project<br />experiences</span></div>
                <div><strong>73</strong><span>Creator<br />uploads</span></div>
                <div><strong>2024</strong><span>BS Information<br />Technology</span></div>
                <div><strong>4×</strong><span>Languages<br />spoken</span></div>
              </div>
            </div>
          </div>
        </section>

        <section className="work shell" id="work">
          <div className="sectionHeading" data-reveal>
            <div>
              <p className="sectionLabel"><span>02</span> ANALYTICS PROJECT LAB</p>
              <h2>Fifteen problems.<br /><em>Fifteen visual systems.</em></h2>
            </div>
            <p>
              Every preview now matches its business problem—from churn rings and cohort heatmaps to network nodes,
              hospital flow and demand forecasts. Click any card to use the interactive project lab.
            </p>
          </div>

          <div className="projectUtility" data-reveal>
            <div className="filterBar" role="group" aria-label="Filter projects">
              {filters.map((item) => (
                <button
                  type="button"
                  key={item}
                  className={filter === item ? "active" : ""}
                  aria-pressed={filter === item}
                  onClick={() => setFilter(item)}
                >
                  {item}
                </button>
              ))}
            </div>
            <span>{String(visibleProjects.length).padStart(2, "0")} EXPERIENCES</span>
          </div>

          <div className="projectGrid">
            {visibleProjects.map((project, index) => (
              <article
                className="projectCard tiltSurface"
                key={project.id}
                style={{ "--accent": project.color, "--delay": `${(index % 3) * 70}ms` } as CSSProperties}
                data-reveal
                onMouseMove={(event) => updatePointerGlow(event.currentTarget, event.clientX, event.clientY)}
                onMouseLeave={(event) => resetTilt(event.currentTarget)}
              >
                <button type="button" onClick={() => setActiveProject(project)} aria-label={`Open ${project.title}`}>
                  <header className="cardHeader"><span>{String(project.id).padStart(2, "0")}</span><small>{project.eyebrow}</small><i>↗</i></header>
                  <ProjectCardVisual project={project} />
                  <div className="cardBody">
                    <h3>{project.title}</h3>
                    <p>{project.summary}</p>
                    <div className="tagRow">{project.tools.slice(0, 3).map((tool) => <span key={tool}>{tool}</span>)}</div>
                  </div>
                  <footer className="cardFooter"><span>Explore experience</span><b>Open lab <i>↗</i></b></footer>
                </button>
              </article>
            ))}
          </div>
        </section>

        <section className="capabilities">
          <div className="shell">
            <div className="capabilityIntro" data-reveal>
              <p className="sectionLabel lightLabel"><span>03</span> HOW I CREATE VALUE</p>
              <h2>One analyst.<br /><em>Four useful modes.</em></h2>
            </div>
            <div className="capabilityGrid">
              {capabilities.map((item, index) => (
                <article
                  key={item.number}
                  className="tiltSurface"
                  data-reveal
                  style={{ "--delay": `${index * 70}ms` } as CSSProperties}
                  onMouseMove={(event) => updatePointerGlow(event.currentTarget, event.clientX, event.clientY)}
                  onMouseLeave={(event) => resetTilt(event.currentTarget)}
                >
                  <span>{item.number}</span><small>{item.signal}</small><h3>{item.title}</h3><p>{item.copy}</p><i>↗</i>
                </article>
              ))}
            </div>
            <div className="toolMatrix" data-reveal>
              {toolGroups.map((group) => (
                <article key={group.title}>
                  <h3>{group.title}</h3>
                  <div>{group.items.map((item) => <span key={item}>{item}</span>)}</div>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className="channel shell" id="channel">
          <div className="channelHero" data-reveal>
            <div className="creatorPortrait">
              <div className="creatorShape" aria-hidden="true" />
              <Image
                src="/sajid-creator-v2.webp"
                alt="Sajid Ali presenting his Sajid Expertise creator work"
                fill
                unoptimized
                style={{ objectFit: "contain", objectPosition: "center bottom" }}
                sizes="(max-width: 900px) 94vw, 42vw"
              />
              <div className="creatorBadge"><i>▶</i><span><small>CREATOR CHANNEL</small><b>Sajid Expertise</b></span></div>
            </div>
            <div className="channelCopy">
              <p className="sectionLabel redLabel"><span>04</span> YOUTUBE × ANALYTICS</p>
              <h2>I publish ideas—and <em>study what connects.</em></h2>
              <p>
                Sajid Expertise covers practical AI tools, technology, digital skills and creator growth.
                The portfolio reads the public upload feed automatically and makes every video playable here.
              </p>
              <div className="channelActions">
                <a className="youtubeButton magnetic" href={channelUrl} target="_blank" rel="noreferrer"><i>▶</i> Visit channel <span>↗</span></a>
                <span className={`syncBadge ${feedSource}`}><i /> {feedSource === "live" ? "LIVE FEED SYNCED" : feedSource === "loading" ? "SYNCING FEED" : "PLAYLIST FALLBACK"}</span>
              </div>
            </div>
          </div>

          <div className="youtubeDashboard" data-reveal aria-label="Sajid Expertise public analytics snapshot">
            <div className="dashboardTitle"><span>SAJID EXPERTISE / PUBLIC STUDIO</span><small>SNAPSHOT · JULY 2026</small></div>
            <div className="channelKpis">
              <article><span>SUBSCRIBERS</span><strong>2,440</strong><small>PUBLIC CHANNEL</small></article>
              <article><span>CHANNEL VIEWS</span><strong>40,604</strong><small>LIFETIME PUBLIC</small></article>
              <article><span>PUBLISHED VIDEOS</span><strong>73</strong><small>UPLOAD LIBRARY</small></article>
              <article><span>NEXT OPPORTUNITY</span><strong>How-to</strong><small>AI + PRACTICAL SKILLS</small></article>
            </div>
            <div className="channelCharts">
              <article className="topicChart">
                <header><span>CONTENT OPPORTUNITY</span><b>TOPIC SIGNAL</b></header>
                <div><span>Practical how-to</span><i><b style={{ width: "92%" }} /></i><small>92</small></div>
                <div><span>AI tools</span><i><b style={{ width: "86%" }} /></i><small>86</small></div>
                <div><span>Creator growth</span><i><b style={{ width: "71%" }} /></i><small>71</small></div>
                <div><span>PC & technology</span><i><b style={{ width: "64%" }} /></i><small>64</small></div>
              </article>
              <article className="publishingChart">
                <header><span>LIBRARY MIX</span><b>73 UPLOADS</b></header>
                <div className="uploadDonut"><strong>73</strong><span>VIDEOS</span></div>
                <p><i /> Every new public upload joins the playlist automatically.</p>
              </article>
              <article className="creatorInsight">
                <span>NEXT EXPERIMENT</span>
                <h3>Pair practical AI topics with outcome-first titles.</h3>
                <p>Use a clear before/after result, one focused thumbnail promise and a repeatable tutorial format.</p>
                <b>PUBLIC-SIGNAL INTERPRETATION</b>
              </article>
            </div>
          </div>

          <div className="playlistSection" data-reveal>
            <div className="playlistCopy">
              <p className="sectionLabel"><span>05</span> COMPLETE VIDEO LIBRARY</p>
              <h2>All uploads.<br /><em>One player.</em></h2>
              <p>The embedded uploads playlist stays connected to the channel, so future public videos appear without rebuilding this page.</p>
            </div>
            <div className="playlistFrame">
              <iframe
                src={`https://www.youtube-nocookie.com/embed/videoseries?list=${uploadsPlaylistId}&rel=0`}
                title="Sajid Expertise complete uploads playlist"
                loading="lazy"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                allowFullScreen
              />
            </div>
          </div>

          <div className="latestHeader" data-reveal>
            <div><p className="sectionLabel"><span>06</span> LATEST FROM THE CHANNEL</p><h2>Click any video to <em>watch here.</em></h2></div>
            <a href={channelUrl} target="_blank" rel="noreferrer">Open YouTube channel ↗</a>
          </div>
          <div className="videoGrid">
            {videos.slice(0, 12).map((video, index) => (
              <button
                type="button"
                className="videoCard tiltSurface"
                key={video.id}
                data-reveal
                style={{ "--delay": `${(index % 3) * 60}ms` } as CSSProperties}
                onClick={() => setActiveVideo(video)}
                onMouseMove={(event) => updatePointerGlow(event.currentTarget, event.clientX, event.clientY)}
                onMouseLeave={(event) => resetTilt(event.currentTarget)}
                aria-label={`Play ${video.title}`}
              >
                <span className="thumbnail" style={{ backgroundImage: `url(${video.thumbnail})` }}>
                  <i>▶</i><small>{String(index + 1).padStart(2, "0")}</small><b>PLAY HERE</b>
                </span>
                <span className="videoMeta"><small>{fixedDate(video.published)}</small><strong>{video.title}</strong><i>Watch video ↗</i></span>
              </button>
            ))}
          </div>
        </section>

        <section className="resumeLanding" id="resume">
          <div className="shell resumeGrid">
            <div className="resumeCopy" data-reveal>
              <p className="sectionLabel"><span>07</span> MY ONE-PAGE PROFILE</p>
              <h2>The full résumé,<br /><em>large and readable.</em></h2>
              <p>
                Review my education, skills, certifications and experience directly on the page—or open the original PDF for interviews and applications.
              </p>
              <div className="resumeActions">
                <a className="button buttonPrimary magnetic" href="/sajid-ali-cv.pdf" target="_blank" rel="noreferrer">Open full CV <span>↗</span></a>
                <a className="button buttonGhost magnetic" href="/sajid-ali-cv.pdf" download>Download PDF <span>↓</span></a>
              </div>
              <div className="resumeHighlights">
                <article><span>FOCUS</span><b>Data analytics</b><p>Power BI, SQL, Python, Excel and practical business analysis.</p></article>
                <article><span>EDGE</span><b>Creator clarity</b><p>Visual communication shaped by hands-on content creation.</p></article>
              </div>
            </div>
            <a
              className="cvPreview tiltSurface"
              href="/sajid-ali-cv.pdf"
              target="_blank"
              rel="noreferrer"
              aria-label="Open Sajid Ali CV as PDF"
              data-reveal
              onMouseMove={(event) => updatePointerGlow(event.currentTarget, event.clientX, event.clientY)}
              onMouseLeave={(event) => resetTilt(event.currentTarget)}
            >
              <span className="cvTopbar"><i /><i /><i /><b>SAJID-ALI-CV.PDF</b><em>OPEN ↗</em></span>
              <Image src="/sajid-ali-cv.webp" alt="Full résumé of Sajid Ali" width={1240} height={1754} unoptimized sizes="(max-width: 900px) 96vw, 54vw" />
            </a>
          </div>
        </section>

        <section className="profiles shell" id="profiles">
          <div className="profilesIntro" data-reveal>
            <p className="sectionLabel"><span>08</span> DIGITAL HEADQUARTERS</p>
            <h2>My work and profiles.<br /><em>All in one place.</em></h2>
            <p>Use the verified links below to review my professional profile, creator channel, CV and contact details.</p>
          </div>
          <div className="profileGrid">
            <a className="profileCard linkedin tiltSurface" href={linkedinUrl} target="_blank" rel="noreferrer" data-reveal>
              <span className="profileIcon">in</span><small>PROFESSIONAL NETWORK</small><h3>LinkedIn</h3><p>Experience, skills, professional updates and direct networking.</p><b>Open verified profile ↗</b>
            </a>
            <a className="profileCard youtube tiltSurface" href={channelUrl} target="_blank" rel="noreferrer" data-reveal>
              <span className="profileIcon">▶</span><small>CREATOR CHANNEL</small><h3>Sajid Expertise</h3><p>Practical AI, technology, digital skills and creator education.</p><b>Watch the channel ↗</b>
            </a>
            <a className="profileCard email tiltSurface" href={`mailto:${email}`} data-reveal>
              <span className="profileIcon">@</span><small>DIRECT CONTACT</small><h3>Email Sajid</h3><p>Roles, internships, collaborations and thoughtful analytics conversations.</p><b>Start an email ↗</b>
            </a>
            <a className="profileCard github tiltSurface" href="https://github.com/" target="_blank" rel="noreferrer" data-reveal>
              <span className="profileIcon">GH</span><small>DEVELOPER PROFILE</small><h3>GitHub launchpad</h3><p>Your verified GitHub username is not in the CV yet. This safe launchpad stays ready for your link.</p><b>Open GitHub ↗</b>
            </a>
          </div>
        </section>

        <section className="contact shell" id="contact" data-reveal>
          <span className="contactGlow glowA" aria-hidden="true" /><span className="contactGlow glowB" aria-hidden="true" />
          <p className="sectionLabel lightLabel"><span>09</span> OPEN TO THE NEXT CHALLENGE</p>
          <h2>Have a question hiding<br />inside your data?</h2>
          <p>I&apos;m open to data analyst roles, internships, collaborations and useful conversations about analytics.</p>
          <div className="contactActions">
            <a className="button buttonLight magnetic" href={`mailto:${email}`}>Email me <span>↗</span></a>
            <a className="button buttonOutline magnetic" href={linkedinUrl} target="_blank" rel="noreferrer">Connect on LinkedIn <span>↗</span></a>
          </div>
          <a className="contactEmail" href={`mailto:${email}`}>{email}</a>
        </section>
      </main>

      <footer className="siteFooter shell">
        <div className="brand footerBrand"><span className="brandMark">SE</span><span className="brandWords"><b>Sajid Expertise</b><small>DATA × STORY × IMPACT</small></span></div>
        <p>Built for interviews, LinkedIn and meaningful opportunities · © 2026 Sajid Ali</p>
        <div><a href={linkedinUrl} target="_blank" rel="noreferrer">LinkedIn</a><a href={channelUrl} target="_blank" rel="noreferrer">YouTube</a><a href="#top">Back to top ↑</a></div>
      </footer>

      {activeProject && <ProjectExperience project={activeProject} onClose={() => setActiveProject(null)} />}

      {activeVideo && (
        <div className="videoModalBackdrop" role="presentation" onMouseDown={(event) => event.target === event.currentTarget && setActiveVideo(null)}>
          <section className="videoModal" role="dialog" aria-modal="true" aria-label={`Playing ${activeVideo.title}`}>
            <button type="button" onClick={() => setActiveVideo(null)} aria-label="Close video">×</button>
            <div className="videoPlayer">
              <iframe
                src={`https://www.youtube-nocookie.com/embed/${activeVideo.id}?autoplay=1&rel=0`}
                title={activeVideo.title}
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                allowFullScreen
              />
            </div>
            <div className="videoModalMeta"><span>SAJID EXPERTISE</span><h2>{activeVideo.title}</h2><a href={activeVideo.url} target="_blank" rel="noreferrer">Open on YouTube ↗</a></div>
          </section>
        </div>
      )}
    </>
  );
}

function ProjectCardVisual({ project }: { project: Project }) {
  const metric = project.metrics[0];
  return (
    <div className={`cardVisual visual-${project.visual}`} aria-hidden="true">
      <div className="miniWindowTop"><i /><i /><i /><span>{project.shortTitle.toUpperCase()}</span></div>
      <div className="visualKpis">
        <div><span>{metric[0]}</span><strong>{formatMetric(metric[1], metric[2], true)}</strong></div>
        <div><span>{project.metrics[1][0]}</span><strong>{formatMetric(project.metrics[1][1], project.metrics[1][2], true)}</strong></div>
      </div>
      <ProjectGraphic project={project} />
    </div>
  );
}

function ProjectGraphic({ project }: { project: Project }) {
  const gradientId = `gradient-${project.id}`;
  switch (project.visual) {
    case "revenue":
      return <div className="graphic revenueGraphic"><svg viewBox="0 0 320 130"><defs><linearGradient id={gradientId} x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="var(--accent)" stopOpacity=".45"/><stop offset="1" stopColor="var(--accent)" stopOpacity="0"/></linearGradient></defs><path className="area" fill={`url(#${gradientId})`} d="M5 108 L45 91 L86 96 L126 62 L166 72 L207 39 L247 49 L315 18 L315 125 L5 125 Z"/><path className="line" d="M5 108 L45 91 L86 96 L126 62 L166 72 L207 39 L247 49 L315 18"/><g>{[45,126,207,315].map((x, i) => <circle key={x} cx={x} cy={[91,62,39,18][i]} r="4" />)}</g></svg><div className="revenueBars">{[48,66,42,82,65,94].map((h) => <i key={h} style={{ height: `${h}%` }} />)}</div></div>;
    case "churn":
      return <div className="graphic churnGraphic"><div className="churnRing"><strong>26.5%</strong><span>CHURN RISK</span></div><div className="riskList"><p><i className="danger" />Month-to-month <b>HIGH</b></p><p><i className="watch" />No support <b>WATCH</b></p><p><i className="safe" />Annual contract <b>STABLE</b></p></div></div>;
    case "youtube":
      return <div className="graphic youtubeGraphic"><div className="youtubeScreen"><i>▶</i><span>CREATOR SIGNAL</span></div><svg viewBox="0 0 210 80"><path d="M3 66 C25 70,31 38,52 46 S84 63,102 29 S134 12,151 34 S181 38,207 8"/><circle cx="207" cy="8" r="4"/></svg><div className="ytTicks"><span>REACH</span><b>+18.4%</b></div></div>;
    case "workforce":
      return <div className="graphic workforceGraphic"><div className="peopleGrid">{["S","R","H","O","F","I"].map((item, index) => <span key={item} className={index === 3 ? "riskPerson" : ""}><i>●</i><b>{item}</b></span>)}</div><div className="attritionLine"><span>ATTRITION TREND</span><svg viewBox="0 0 180 45"><path d="M2 35 L32 31 L61 34 L91 22 L121 26 L150 12 L178 17"/></svg></div></div>;
    case "inventory":
      return <div className="graphic inventoryGraphic"><div className="warehouse">{[2,3,2,4].map((count, row) => <div key={row}>{Array.from({ length: count }).map((_, index) => <i key={index} className={row === 3 && index > 1 ? "low" : ""} />)}</div>)}</div><div className="stockGauge"><span>STOCK COVER</span><b><i style={{ width: "68%" }} /></b><small>68% HEALTHY</small></div></div>;
    case "finance":
      return <div className="graphic financeGraphic"><div className="waterfall">{[{h:58,c:"up"},{h:74,c:"up"},{h:41,c:"down"},{h:87,c:"up"},{h:52,c:"down"},{h:93,c:"total"}].map((bar,index) => <span key={index}><i className={bar.c} style={{ height: `${bar.h}%` }} /><small>{["REV","GP","OPEX","EBIT","TAX","NET"][index]}</small></span>)}</div><p><span>●</span> ACTUAL <i>●</i> BUDGET</p></div>;
    case "funnel":
      return <div className="graphic funnelGraphic"><div className="funnel"><i style={{ width: "100%" }}><b>92K</b><span>REACH</span></i><i style={{ width: "78%" }}><b>18K</b><span>CLICKS</span></i><i style={{ width: "56%" }}><b>6.8K</b><span>LEADS</span></i><i style={{ width: "34%" }}><b>1.4K</b><span>SALES</span></i></div><div className="roasPill"><span>ROAS</span><b>4.2×</b></div></div>;
    case "hospital":
      return <div className="graphic hospitalGraphic"><div className="pulseLine"><svg viewBox="0 0 310 85"><path d="M2 48 L55 48 L67 33 L80 64 L96 12 L112 70 L130 48 L166 48 L178 38 L190 56 L204 25 L218 61 L235 48 L308 48"/></svg><i /></div><div className="bedRows"><span>ER <b>83%</b></span><span>ICU <b>78%</b></span><span>OPD <b>69%</b></span></div></div>;
    case "network":
      return <div className="graphic networkGraphic"><svg viewBox="0 0 320 155"><g className="links"><path d="M32 84 L92 35 L160 72 L226 28 L287 73 M92 35 L113 123 L160 72 L218 128 L287 73 M113 123 L218 128"/></g><g className="nodes">{[[32,84],[92,35],[160,72],[226,28],[287,73],[113,123],[218,128]].map(([x,y],i) => <g key={i}><circle cx={x} cy={y} r={i === 4 ? 11 : 7}/><circle className="ping" cx={x} cy={y} r={i === 4 ? 18 : 12}/></g>)}</g></svg><span className="uptimePill">99.84% UPTIME</span></div>;
    case "property":
      return <div className="graphic propertyGraphic"><div className="mapGrid"><i className="road rA"/><i className="road rB"/><i className="road rC"/><span className="pin pA"><b>6.7%</b></span><span className="pin pB"><b>5.9%</b></span><span className="pin pC"><b>7.2%</b></span><span className="pin pD"><b>6.3%</b></span></div><div className="mapLegend"><span><i /> HIGH YIELD</span><b>HYDERABAD</b></div></div>;
    case "customer":
      return <div className="graphic customerGraphic"><div className="customerOrbit"><i className="orbit orbitA"/><i className="orbit orbitB"/><span className="customerCenter">C360</span><b className="node nA">VIP</b><b className="node nB">RFM</b><b className="node nC">LTV</b><b className="node nD">NBO</b></div><p>ONE CUSTOMER · FOUR SIGNALS</p></div>;
    case "forecast":
      return <div className="graphic forecastGraphic"><svg viewBox="0 0 320 135"><defs><linearGradient id={gradientId} x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="var(--accent)" stopOpacity=".3"/><stop offset="1" stopColor="var(--accent)" stopOpacity="0"/></linearGradient></defs><path className="confidence" fill={`url(#${gradientId})`} d="M170 43 L205 35 L240 19 L275 27 L316 5 L316 88 L275 78 L240 82 L205 68 L170 73 Z"/><path className="actual" d="M3 102 L38 87 L73 91 L108 62 L143 69 L170 54"/><path className="future" d="M170 54 L205 47 L240 35 L275 44 L316 24"/><line x1="170" y1="8" x2="170" y2="122"/><text x="178" y="116">FORECAST</text></svg><span>MAPE <b>7.4%</b></span></div>;
    case "fraud":
      return <div className="graphic fraudGraphic"><div className="scatter">{[[8,72,0],[18,61,0],[27,79,0],[37,55,0],[46,70,0],[55,43,1],[64,64,0],[72,31,1],[81,48,1],[89,18,2],[94,39,2],[61,21,1]].map(([x,y,risk],i) => <i key={i} className={`risk${risk}`} style={{ left: `${x}%`, top: `${y}%` }} />)}<span className="reviewZone">REVIEW ZONE</span></div><div className="fraudLegend"><span>LOW</span><span>WATCH</span><span>REVIEW</span></div></div>;
    case "cohort":
      return <div className="graphic cohortGraphic"><div className="heatmap">{Array.from({ length: 36 }).map((_, index) => <i key={index} style={{ opacity: Math.max(.16, .96 - (index % 6) * .13 - Math.floor(index / 6) * .06) }} />)}</div><div className="cohortLabels"><span>M0</span><span>M1</span><span>M2</span><span>M3</span><span>M4</span><span>M5</span></div></div>;
    case "energy":
      return <div className="graphic energyGraphic"><svg viewBox="0 0 320 126"><defs><linearGradient id={gradientId} x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="var(--accent)" stopOpacity=".48"/><stop offset="1" stopColor="var(--accent)" stopOpacity="0"/></linearGradient></defs><path fill={`url(#${gradientId})`} d="M0 106 C40 96,60 72,98 75 S150 92,181 55 S235 17,265 35 S296 54,320 22 L320 126 L0 126 Z"/><path className="loadLine" d="M0 106 C40 96,60 72,98 75 S150 92,181 55 S235 17,265 35 S296 54,320 22"/></svg><div className="energyMix"><span>HYDRO <b>32%</b></span><span>SOLAR <b>19%</b></span><span>THERMAL <b>49%</b></span></div></div>;
  }
}

function ProjectExperience({ project, onClose }: { project: Project; onClose: () => void }) {
  const [tab, setTab] = useState<"dashboard" | "method" | "data">("dashboard");
  const [period, setPeriod] = useState<"3M" | "6M" | "12M">("12M");
  const [segment, setSegment] = useState<"All" | "Growth" | "Risk">("All");
  const [scenario, setScenario] = useState(100);

  useEffect(() => {
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const onKeyDown = (event: KeyboardEvent) => event.key === "Escape" && onClose();
    window.addEventListener("keydown", onKeyDown);
    return () => {
      document.body.style.overflow = previousOverflow;
      window.removeEventListener("keydown", onKeyDown);
    };
  }, [onClose]);

  const periodFactor = period === "3M" ? 0.76 : period === "6M" ? 0.89 : 1;
  const segmentFactor = segment === "Growth" ? 1.13 : segment === "Risk" ? 0.82 : 1;
  const factor = periodFactor * segmentFactor * (scenario / 100);
  const adjustedBars = project.bars.map((bar, index) => Math.min(98, Math.max(12, bar * factor + (index % 2 ? scenario - 100 : 0))));
  const adjustedMetrics = project.metrics.map(([label, value, unit]) => [label, value * factor, unit] as [string, number, string]);

  const download = (kind: "csv" | "brief") => {
    const content = kind === "csv"
      ? ["dimension,value,scenario", ...project.labels.map((label, index) => `${label},${adjustedBars[index]?.toFixed(1) ?? 0},${scenario}`)].join("\n")
      : `${project.title}\n\nBusiness question\n${project.question}\n\nKey insight\n${project.insight}\n\nDecision outcome\n${project.outcome}\n\nWorkflow\n${project.workflow.map((step, index) => `${index + 1}. ${step}`).join("\n")}\n\nPortfolio simulation by Sajid Ali.`;
    const blob = new Blob([content], { type: kind === "csv" ? "text/csv" : "text/plain" });
    const href = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = href;
    link.download = `${project.shortTitle.toLowerCase().replace(/[^a-z0-9]+/g, "-")}-${kind === "csv" ? "demo-data.csv" : "project-brief.txt"}`;
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(href);
  };

  const onBackdrop = (event: ReactMouseEvent<HTMLDivElement>) => {
    if (event.target === event.currentTarget) onClose();
  };

  return (
    <div className="modalBackdrop" role="presentation" onMouseDown={onBackdrop}>
      <section className="projectModal" role="dialog" aria-modal="true" aria-labelledby="project-modal-title" style={{ "--accent": project.color } as CSSProperties}>
        <button className="modalClose" type="button" onClick={onClose} aria-label="Close project">×</button>
        <header className="modalHeader">
          <div><span>{project.eyebrow}</span><h2 id="project-modal-title">{project.title}</h2><p>{project.summary}</p></div>
          <button type="button" className="exportButton" onClick={() => download("brief")}>Download brief <span>↓</span></button>
        </header>

        <div className="modalTabs" role="tablist" aria-label="Project experience sections">
          {(["dashboard", "method", "data"] as const).map((item) => <button key={item} type="button" role="tab" aria-selected={tab === item} className={tab === item ? "active" : ""} onClick={() => setTab(item)}>{item}</button>)}
        </div>

        {tab === "dashboard" && (
          <div className="dashboardTab" role="tabpanel">
            <div className="dashboardControls">
              <div><span>PERIOD</span>{(["3M", "6M", "12M"] as const).map((item) => <button key={item} type="button" className={period === item ? "active" : ""} onClick={() => setPeriod(item)}>{item}</button>)}</div>
              <div><span>SEGMENT</span>{(["All", "Growth", "Risk"] as const).map((item) => <button key={item} type="button" className={segment === item ? "active" : ""} onClick={() => setSegment(item)}>{item}</button>)}</div>
              <label><span>SCENARIO</span><input type="range" min="80" max="125" value={scenario} onChange={(event) => setScenario(Number(event.target.value))} /><b>{scenario}%</b></label>
            </div>
            <div className="dashboardKpis">{adjustedMetrics.map(([label, value, unit], index) => <article key={label}><span>{label}</span><strong>{formatMetric(value, unit)}</strong><small>{index === 1 ? "LIVE FILTERED VIEW" : `${value >= project.metrics[index][1] ? "+" : ""}${((value / project.metrics[index][1] - 1) * 100).toFixed(1)}% VS BASE`}</small></article>)}</div>
            <div className="dashboardGrid">
              <article className="mainChart"><header><div><span>PERFORMANCE VIEW</span><b>{project.shortTitle}</b></div><small>{period} · {segment.toUpperCase()}</small></header><div className="chartPlot"><div className="gridLines"><i /><i /><i /><i /></div><div className="largeBars">{adjustedBars.map((height, index) => <div key={project.labels[index]}><i style={{ height: `${height}%` }} /><span>{project.labels[index]}</span></div>)}</div></div></article>
              <article className="insightPanel"><span>ANALYST SIGNAL</span><div className="signalGauge" style={{ "--gauge": `${Math.min(94, 58 + scenario / 4)}%` } as CSSProperties}><b>{Math.round(Math.min(94, 58 + scenario / 4))}</b><small>CONFIDENCE</small></div><h3>{segment === "Risk" ? "Risk lens active" : segment === "Growth" ? "Growth lens active" : "Portfolio view"}</h3><p>{project.insight}</p><div className="recommended"><i /><span><b>Recommended action</b>{project.outcome}</span></div></article>
            </div>
          </div>
        )}

        {tab === "method" && (
          <div className="methodTab" role="tabpanel">
            <article className="questionCard"><span>BUSINESS QUESTION</span><h3>{project.question}</h3><p>{project.outcome}</p></article>
            <div className="workflow">{project.workflow.map((step, index) => <article key={step}><span>0{index + 1}</span><i /><small>{["PREPARE", "MODEL", "ANALYZE", "COMMUNICATE"][index]}</small><h4>{step}</h4></article>)}</div>
            <div className="methodFooter"><div><span>TOOLS</span><p>{project.tools.map((tool) => <b key={tool}>{tool}</b>)}</p></div><div><span>DISCLOSURE</span><p>This is an original portfolio simulation built to demonstrate analytical thinking, data storytelling and interface design.</p></div></div>
          </div>
        )}

        {tab === "data" && (
          <div className="dataTab" role="tabpanel">
            <div className="dataToolbar"><div><span>DEMO DATA EXPLORER</span><small>Six representative rows · scenario adjusted</small></div><button type="button" onClick={() => download("csv")}>Export CSV ↓</button></div>
            <div className="dataTableWrap"><table><thead><tr><th>Dimension</th><th>Base score</th><th>Adjusted</th><th>Scenario</th><th>Status</th></tr></thead><tbody>{project.labels.map((label, index) => { const value = adjustedBars[index] ?? 0; const status = value > 75 ? "Strong" : value > 48 ? "Watch" : "Risk"; return <tr key={label}><td>{label}</td><td>{project.bars[index]}</td><td>{value.toFixed(1)}</td><td>{scenario}%</td><td><span className={status.toLowerCase()}>{status}</span></td></tr>; })}</tbody></table></div>
            <p className="dataDisclosure"><i /> Demo values are generated for learning and portfolio presentation. Downloading creates a local CSV from the active controls.</p>
          </div>
        )}
      </section>
    </div>
  );
}

function formatMetric(value: number, unit: string, compact = false) {
  const absolute = Math.abs(value);
  let display: string;
  if (compact && absolute >= 1_000_000) display = `${(value / 1_000_000).toFixed(2)}M`;
  else if (compact && absolute >= 1_000) display = `${(value / 1_000).toFixed(value >= 10_000 ? 1 : 2)}K`;
  else if (Number.isInteger(value)) display = Math.round(value).toLocaleString("en-US");
  else display = value.toFixed(1);
  if (unit === "$") return `$${display}`;
  return `${display}${unit}`;
}
