import { NextResponse } from "next/server";

const channelId = "UC6ZckektFwLUMnZ4bSHKQhQ";

const fallbackVideos = [
  {
    id: "t9_Byx-j0Ws",
    title: "5 High-Paying Skills to Learn Before 2030",
    published: "2026-01-01T00:00:00.000Z",
  },
  {
    id: "1O3rmIa5HzU",
    title: "Top 5 Free AI Tools Everyone Must Use",
    published: "2026-01-01T00:00:00.000Z",
  },
  {
    id: "pUkQSHW7W6Y",
    title: "Viral YouTube Thumbnail Ideas",
    published: "2026-01-01T00:00:00.000Z",
  },
].map((video) => ({
  ...video,
  url: `https://www.youtube.com/watch?v=${video.id}`,
  thumbnail: `https://i.ytimg.com/vi/${video.id}/hqdefault.jpg`,
}));

function decodeXml(value: string) {
  return value
    .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, "$1")
    .replace(/&amp;/g, "&")
    .replace(/&quot;/g, '"')
    .replace(/&#39;|&apos;/g, "'")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">");
}

function tag(entry: string, name: string) {
  const match = entry.match(new RegExp(`<${name}(?:\\s[^>]*)?>([\\s\\S]*?)<\\/${name}>`));
  return match ? decodeXml(match[1].trim()) : "";
}

export async function GET() {
  try {
    const response = await fetch(
      `https://www.youtube.com/feeds/videos.xml?channel_id=${channelId}`,
      {
        headers: { "User-Agent": "Sajid-Expertise-Portfolio/1.0" },
        next: { revalidate: 1800 },
      },
    );

    if (!response.ok) throw new Error(`YouTube feed returned ${response.status}`);

    const xml = await response.text();
    const entries = xml.match(/<entry>[\s\S]*?<\/entry>/g) ?? [];
    const videos = entries
      .map((entry) => {
        const id = tag(entry, "yt:videoId");
        if (!id) return null;
        return {
          id,
          title: tag(entry, "title") || "Sajid Expertise video",
          published: tag(entry, "published"),
          url: `https://www.youtube.com/watch?v=${id}`,
          thumbnail: `https://i.ytimg.com/vi/${id}/hqdefault.jpg`,
        };
      })
      // Keep the "Latest from the channel" grid to long-form uploads only — no Shorts.
      .filter((video): video is NonNullable<typeof video> => Boolean(video) && !/#\s?shorts?\b/i.test(video!.title));

    return NextResponse.json(
      { videos: videos.length ? videos : fallbackVideos, source: videos.length ? "live" : "fallback" },
      {
        headers: {
          "Cache-Control": "public, s-maxage=1800, stale-while-revalidate=86400",
        },
      },
    );
  } catch {
    return NextResponse.json(
      { videos: fallbackVideos, source: "fallback" },
      {
        headers: {
          "Cache-Control": "public, s-maxage=300, stale-while-revalidate=3600",
        },
      },
    );
  }
}
