import type { Metadata, Viewport } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  metadataBase: new URL("https://sajid-expertise-pro.sajidrindofficial.chatgpt.site"),
  title: {
    default: "Sajid Expertise | Data Analyst & YouTube Creator",
    template: "%s | Sajid Expertise",
  },
  description: "Explore Sajid Ali's professional data analyst and YouTube creator portfolio with 15 interactive Power BI, SQL, Python, Excel and creator analytics experiences.",
  keywords: [
    "Sajid Ali",
    "Sajid Expertise",
    "data analyst portfolio",
    "Power BI portfolio",
    "SQL projects",
    "Python data analysis",
    "Excel dashboard",
    "YouTube analytics",
    "Sajid Expertise YouTube",
    "Pakistan data analyst",
  ],
  authors: [{ name: "Sajid Ali" }],
  creator: "Sajid Ali",
  publisher: "Sajid Expertise",
  alternates: { canonical: "/" },
  robots: {
    index: true,
    follow: true,
    googleBot: { index: true, follow: true, "max-image-preview": "large", "max-snippet": -1 },
  },
  openGraph: {
    type: "website",
    locale: "en_US",
    url: "/",
    siteName: "Sajid Expertise",
    title: "Sajid Expertise | Interactive Data Analyst Portfolio",
    description: "Fifteen interactive analytics projects, a readable résumé, auto-updating YouTube videos and a decision-focused approach to data.",
    images: [{ url: "/sajid-hero-v2.png", width: 862, height: 1825, alt: "Sajid Ali — Data Analyst and YouTube Creator" }],
  },
  twitter: {
    card: "summary_large_image",
    title: "Sajid Expertise | Data Analyst Portfolio",
    description: "Explore 15 interactive analytics project experiences by Sajid Ali.",
    images: ["/sajid-hero-v2.png"],
  },
  other: {
    "codex-preview": "development",
  },
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 5,
  themeColor: "#f5f1ec",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        suppressHydrationWarning
        className={`${geistSans.variable} ${geistMono.variable} antialiased`}
      >
        {children}
      </body>
    </html>
  );
}
