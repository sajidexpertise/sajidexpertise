import type { MetadataRoute } from "next";

export default function robots(): MetadataRoute.Robots {
  return {
    rules: { userAgent: "*", allow: "/" },
    sitemap: "https://sajid-expertise-pro.sajidrindofficial.chatgpt.site/sitemap.xml",
  };
}
