import type { MetadataRoute } from "next";

export default function sitemap(): MetadataRoute.Sitemap {
  return [
    {
      url: "https://sajid-expertise-pro.sajidrindofficial.chatgpt.site",
      lastModified: new Date("2026-07-20"),
      changeFrequency: "monthly",
      priority: 1,
    },
  ];
}
